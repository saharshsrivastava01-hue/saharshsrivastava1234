# ADVERA 2080 — research and integration register

Research snapshot prepared 17 November 2026. This is a curated starting set, not an exhaustive search of every AI paper or model. Verify licenses, release status, hardware requirements, and terms before adoption.

## Browser 3D / neural rendering

- WebSplatter — WebGPU-native browser 3D Gaussian Splatting, wait-free radix sort and opacity-aware rasterisation. Paper: https://arxiv.org/abs/2602.03207 ; project/demo: https://websplatter.github.io/ . Candidate for an optional advanced scene viewer; not yet integrated in this starter.
- MatrixSplat — matrix-parallel, feature-scalable 3DGS rendering. Paper: https://arxiv.org/abs/2611.15153 . Research candidate; likely requires specialised GPU work and is not a drop-in browser dependency.
- Three.js — https://github.com/mrdoob/three.js ; current prototype uses its WebGL renderer. WebGPU migration should be tested device by device.
- glTF / GLB — https://www.khronos.org/gltf/ ; use for portable product models.

## AI model orchestration / agents

- LiteLLM — https://github.com/BerriAI/litellm ; provider gateway candidate. Check deployment and provider compatibility.
- Inference Gateway — https://github.com/inference-gateway/inference-gateway ; multi-provider gateway with MCP/A2A and telemetry features described by its project.
- Awesome AI Agents — https://github.com/kantorcodes/awesome-ai-agents-6 ; ecosystem directory for agent frameworks, evals, memory, observability and security.
- Awesome Multimodal LLMs — https://github.com/Awesome-llms-labs/awesome-multimodal-llms ; catalogue for vision, video and audio model research.
- MCP specification — https://modelcontextprotocol.io/ ; tool/resource integration protocol.
- A2A protocol — https://a2a-protocol.org/ ; agent-to-agent interoperability.

## Multimodal / world models

- NVIDIA Cosmos 3 technical report (2026-06-22): https://research.nvidia.com/labs/cosmos-lab/cosmos3/technical-report.pdf ; GitHub: https://github.com/nvidia/cosmos . Omnimodal world-model research; not a browser product renderer and may require substantial compute/licensing review.
- 2026 review of 3D point clouds and multimodal LLMs: https://doi.org/10.1016/j.imavis.2026.106202 . Useful taxonomy for future 3D scene understanding.

## Integration policy

1. Do not install every model. Select by task, license, latency, privacy, quality, hardware and cost.
2. Route text reasoning, image understanding, speech, embeddings and 3D generation to separate model classes.
3. Keep provider keys on the server; never in frontend JavaScript.
4. Add evaluation sets, prompt-injection defenses, rate limits, moderation, logging controls and cost budgets before public access.
5. The current prototype uses a single OpenAI-compatible gateway adapter. It does not bundle or claim to connect every listed model.

"""ADVERA 2090 commerce experience API. Demo catalogue; no payment or user PII."""
from __future__ import annotations
import os, sqlite3, json, time, uuid, re
from pathlib import Path
from typing import Literal
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv('ADVERA_DB_PATH', str(ROOT / 'advera.db')))
PRODUCTS = [
 {"id":"ion-headphones","slug":"headphones","name":"ION Spatial Headphones","category":"audio","price_inr":12990,"finish_options":["Nebula Violet","Titanium Silver","Bio Mint","Solar Amber"],"description":"Sculpted concept headphones for immersive listening."},
 {"id":"chrono-watch","slug":"watch","name":"CHRONO Smartwatch","category":"wearable","price_inr":18990,"finish_options":["Nebula Violet","Titanium Silver","Bio Mint","Solar Amber"],"description":"A precision timepiece concept with a luminous interface."},
 {"id":"vector-sneaker","slug":"sneaker","name":"VECTOR Performance Sneaker","category":"footwear","price_inr":9990,"finish_options":["Nebula Violet","Titanium Silver","Bio Mint","Solar Amber"],"description":"A sculptural performance silhouette with layered materials."},
]
app = FastAPI(title='ADVERA 2090 Experience API', version='0.5.0', description='Product discovery, event analytics and optional AI gateway.')
origins = [x.strip() for x in os.getenv('CORS_ORIGINS','http://localhost:8000,http://127.0.0.1:8000').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=['GET','POST'], allow_headers=['Content-Type','Authorization'])


def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY, event TEXT NOT NULL, product TEXT, referral TEXT, session_id TEXT, created_at INTEGER NOT NULL)''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at)')
        con.execute('CREATE INDEX IF NOT EXISTS idx_events_type ON events(event)')
init_db()

class EventIn(BaseModel):
    event: Literal['page_view','product_view','configure','share','add_to_bag','copilot_request']
    product: str | None = Field(default=None, max_length=64)
    referral: str | None = Field(default=None, max_length=40)
    session_id: str = Field(min_length=8, max_length=80)
class RecommendIn(BaseModel):
    prompt: str = Field(min_length=2, max_length=1000)
class CopilotIn(BaseModel):
    task: Literal['product_help','campaign_idea','product_compare'] = 'product_help'
    prompt: str = Field(min_length=3, max_length=4000)

@app.middleware('http')
async def security_headers(request: Request, call_next):
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    response.headers['Permissions-Policy']='camera=(), microphone=(self), geolocation=()'
    return response

@app.get('/')
def root(): return {'service':'ADVERA 2090 API','docs':'/docs','health':'/health'}
@app.get('/health')
def health():
    return {'status':'ok','service':'advera-2090-api','version':app.version,'ai_gateway_configured':bool(os.getenv('AI_GATEWAY_URL') and os.getenv('AI_GATEWAY_API_KEY')),'database':'sqlite'}
@app.get('/api/products')
def products(): return {'items':PRODUCTS,'currency':'INR','catalogue_mode':'concept_demo'}
@app.post('/api/events', status_code=202)
def record_event(item: EventIn, request: Request):
    known={p['slug'] for p in PRODUCTS}
    if item.product and item.product not in known: raise HTTPException(400,'Unknown product slug')
    with db() as con:
        con.execute('INSERT INTO events VALUES(?,?,?,?,?,?)',(str(uuid.uuid4()),item.event,item.product,item.referral,item.session_id,int(time.time())))
    return {'accepted':True}
@app.get('/api/analytics/summary')
def analytics_summary():
    with db() as con:
        rows=con.execute('SELECT event, COUNT(*) n FROM events WHERE created_at >= ? GROUP BY event',(int(time.time())-30*86400,)).fetchall()
    return {'window_days':30,'events':{r['event']:r['n'] for r in rows},'privacy':'aggregate event counts; no names or email addresses collected'}

@app.post('/api/recommend')
def recommend(req: RecommendIn):
    q=req.prompt.lower()
    if re.search(r'headphone|music|audio|sound|creator',q): chosen=PRODUCTS[0]; reason='Audio and creator-focused requests point to the ION headphones.'
    elif re.search(r'shoe|sneaker|run|sport|walk',q): chosen=PRODUCTS[2]; reason='Movement and sporty styling point to the VECTOR sneaker.'
    elif re.search(r'watch|time|wearable|premium|luxury|formal',q): chosen=PRODUCTS[1]; reason='A refined everyday accessory points to the CHRONO watch.'
    else: chosen=PRODUCTS[1]; reason='A versatile starting point from the current concept catalogue.'
    return {'product':chosen,'reason':reason,'mode':'local_rules','notice':'This is a transparent baseline recommender, not a trained personalisation model.'}

@app.post('/api/copilot')
async def copilot(req: CopilotIn):
    base=os.getenv('AI_GATEWAY_URL'); key=os.getenv('AI_GATEWAY_API_KEY'); model=os.getenv('AI_MODEL')
    if not (base and key and model):
        if req.task=='campaign_idea':
            answer=f"Campaign direction for: {req.prompt}\n\nHook: reveal one memorable product detail in the first three seconds.\nExperience: let visitors inspect a product and customise one finish.\nShare loop: generate a personalised build link and invite a friend.\nMeasurement: compare landing visits, product views, shares and add-to-bag events."
        else:
            answer='The live AI provider is not configured yet. I can still recommend from the demo catalogue: headphones for audio, sneaker for sport, or watch for a refined everyday look. Add an AI gateway on the backend to enable model-generated answers.'
        return {'provider':'local-fallback','model':'rules-v1','response':answer,'ai_connected':False}
    system=('You are ADVERA 2090 product discovery assistant. Only use this concept catalogue: '+json.dumps(PRODUCTS)+'. Never invent stock, discounts, product specifications, delivery promises or payment status. Clearly state when information is unavailable.')
    payload={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':f'Task: {req.task}\nRequest: {req.prompt}'}],'temperature':0.4}
    try:
        async with httpx.AsyncClient(timeout=40) as client:
            resp=await client.post(base.rstrip('/')+'/chat/completions',json=payload,headers={'Authorization':f'Bearer {key}'})
            resp.raise_for_status(); data=resp.json()
        answer=data['choices'][0]['message']['content']
        return {'provider':'configured-openai-compatible-gateway','model':model,'response':answer,'ai_connected':True}
    except (httpx.HTTPError,KeyError,IndexError,ValueError) as exc:
        raise HTTPException(502,f'AI provider request failed: {type(exc).__name__}') from exc

@app.exception_handler(Exception)
async def safe_error(request: Request, exc: Exception):
    return JSONResponse(status_code=500,content={'detail':'Unexpected server error','request_path':request.url.path})

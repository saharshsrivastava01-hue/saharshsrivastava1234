# ADVERA 2090 — Ambient Luxury Commerce (prototype)

A mobile-first 3D commerce experience with a FastAPI service, SQLite event analytics, a transparent baseline recommender, and an optional OpenAI-compatible AI gateway.

## What is implemented

- Three.js WebGL product viewer with procedural concept products, auto-view, drag rotation and finish selection.
- Low-friction product presets, local demo bag and shareable product/finish/referral URLs.
- Frontend calls the backend for recommendations and event collection; it falls back to a local recommendation if the API is offline.
- FastAPI endpoints: `GET /health`, `GET /api/products`, `POST /api/recommend`, `POST /api/events`, `GET /api/analytics/summary`, `POST /api/copilot`.
- SQLite stores aggregate event records. No customer name, email, address or payment data is collected.
- Optional server-side OpenAI-compatible chat-completions gateway. No API key belongs in browser code.

## Run locally on Windows / macOS / Linux

Terminal 1 — backend:

```bash
cd advera2090/backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8001
```

Terminal 2 — frontend:

```bash
cd advera2090/frontend
python -m http.server 8000
```

Open `http://127.0.0.1:8000`. API defaults to `http://127.0.0.1:8001`.

## Run frontend on Samsung Android (one command after extracting ZIP)

1. Install **Termux** from its official F-Droid/GitHub distribution, extract the ZIP into `Download`, and open Termux.
2. Paste this one command (it grants storage access, installs Python, starts the frontend server):

```bash
termux-setup-storage && pkg install python -y && cd ~/storage/downloads/advera2090/frontend && python -m http.server 8000
```

3. Keep Termux open and visit `http://127.0.0.1:8000` in Chrome. If your extracted folder has a different name/location, adjust the `cd` path. Three.js loads from a CDN, so internet is required.

The frontend works without the backend, using local fallback recommendations. To enable API-backed recommendations and shared analytics on Android, run the backend in a second Termux session after installing dependencies: `cd ~/storage/downloads/advera2090/backend && pip install -r requirements.txt && uvicorn main:app --host 127.0.0.1 --port 8001`. For local API use from the Android browser, set `window.ADVERA_API_BASE='http://127.0.0.1:8001'` before `app.js` if needed; that is already the default.

## Optional AI provider

Copy `.env.example` to `.env` and set `AI_GATEWAY_URL`, `AI_GATEWAY_API_KEY`, and `AI_MODEL` on the backend host. The configured endpoint must expose an OpenAI-compatible `/chat/completions` route. Environment variables must be set in the server process; the sample does not automatically load `.env`.

## Deployment architecture

- Static frontend: Cloudflare Pages or another static host.
- Backend: a separate Python ASGI host/container with persistent disk for SQLite, or migrate to managed PostgreSQL for production.
- Set backend `CORS_ORIGINS` to the exact deployed frontend origin(s).
- Set `window.ADVERA_API_BASE` to the backend HTTPS origin before loading `app.js` (or replace the default in `app.js`).
- Use HTTPS for both services.

## Production gaps — do not treat this as a live store

This is a prototype, not a production checkout system. It has no real customer authentication, order lifecycle, payment integration, inventory, tax/shipping logic, admin console, fraud controls, rate limiting, consent-management UI, or production monitoring. SQLite and the simple rules recommender are starter components, not scalable AI infrastructure. Add security review, privacy/legal review, load tests, backups, and payment-provider compliance before accepting money.
